setwd("C:\\Users\\IT24102491\\Desktop\\Lab06")

#Question 1
#i.The distribution of X is a binomial distribution
#ii.
1-pbinom(46,50,0.85,lower.tail=TRUE)

#Question 2
#i.number of calls recieved by the call center for the hour

#ii.the distribution of X is poisson

#iii. P(X=15)
dpois(15,lambda = 12)

