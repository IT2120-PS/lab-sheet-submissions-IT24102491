setwd("C:\\Users\\IT24102491\\Desktop\\IT24102491Lab04")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = "\t")
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)  
summary(branch_data)
str(branch_data)
boxplot(branch_data$Sales, main = "Boxplot of Sales",  ylab = "Sales Amount", col = "lightblue",  border = "darkblue")
head(branch_data)  
fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)
find_outliers <- function(x) {
  
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  
  
  IQR_value <- Q3 - Q1
  
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  return(outliers)
}
outliers_years <- find_outliers(branch_data$Years)
print(outliers_years)
